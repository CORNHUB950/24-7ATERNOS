require("dotenv").config();

const mineflayer = require("mineflayer");

const bot = mineflayer.createBot({
  host: process.env.JAVA_HOST,
  port: Number(process.env.JAVA_PORT || 25565),
  username: process.env.JAVA_USERNAME || "Jonny_Sins"
});

bot.once("spawn", () => {
  console.log("🟩 Jonny Sins connected to Java!");
});

bot.on("chat", (username, message) => {
  if (username === bot.username) return;

  console.log(`[Java] ${username}: ${message}`);

  if (message.toLowerCase() === "hello jonny") {
    bot.chat(`Hello ${username}! 😎`);
  }

  if (message.toLowerCase() === "!ping") {
    bot.chat("Pong! 🏓");
  }
});

bot.on("kicked", reason => {
  console.log("Java bot kicked:", reason);
});

bot.on("error", error => {
  console.error("Java error:", error.message);
});

bot.on("end", () => {
  console.log("Java connection ended.");
});
