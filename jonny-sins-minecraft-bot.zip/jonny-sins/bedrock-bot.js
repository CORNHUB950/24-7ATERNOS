require("dotenv").config();

const { createClient } = require("bedrock-protocol");

const client = createClient({
  host: process.env.BEDROCK_HOST,
  port: Number(process.env.BEDROCK_PORT || 19132),
  username: process.env.BEDROCK_USERNAME || "Jonny_Sins"
});

client.on("join", () => {
  console.log("🟦 Jonny Sins connected to Bedrock!");
});

client.on("text", packet => {
  console.log("[Bedrock]", packet);
});

client.on("disconnect", packet => {
  console.log("Bedrock disconnected:", packet);
});

client.on("error", error => {
  console.error("Bedrock error:", error);
});
